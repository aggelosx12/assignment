#include "ASTexec.h"
#include "AST.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

struct ExecEnviron
{
	int x; /* The value of the x variable, a real language would have some name->value lookup table instead */
};

static int execTermExpression(struct ExecEnviron* e, struct AstElement* a);
static int execBinExpression(struct ExecEnviron* e, struct AstElement* a);
static void	execAssignment(struct ExecEnviron* e, struct AstElement* a);
static void	execWhile(struct ExecEnviron* e, struct AstElement* a);
static void execFunctionCall(struct ExecEnviron* e, struct AstElement* a);
static void	execStmt(struct ExecEnviron* e, struct AstElement* a);

/* Lookup Array for AST elements which yields values */
static int (*valExecs[])(struct ExecEnviron* e, struct AstElement* a) =
{
	execTermExpression,
	execTermExpression,
	execBinExpression,
	NULL,
	NULL,
	NULL,
	NULL
};

/* Lookup Array for non-value AST elements */
static void (*runExecs[])(struct ExecEnviron* e, struct AstElement* a) =
{
	NULL, /* ID and numbers are canonical and don't need to be executed */
	NULL,
	NULL,
	execAssignment,
	execWhile,
	execFunctionCall,
	execStmt
};

static int dispatchExpression(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(valExecs[a->kind]);
	return valExecs[a->kind](e, a);
}

static int dispatchStatement(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(runExecs[a->kind]);
	runExecs[a->kind](e, a);
}


static void onlyName(const char* name, const char* reference, const char* kind)
{
	if (strcmp(reference, name))
	{
		fprintf(stderr, "This language knows only the %s '%s', not '%s'\n", kind, reference, name);
		exit(1);
	}
}

static void onlyX(const	char* name)
{
	onlyName(name, "x", "variable");
}

static void	onlyPrint(const	char* name)
{
	onlyName(name, "print", "function");
}

static int execTermExpression(struct ExecEnviron* e, struct AstElement* a)
{
	/* This function handles two different kinds of	AstElement.
	* I would refactor it to an execNameExp and execVal
	* function to get rid of this two if statements. */
	assert(a);
	if (ekNumber == a->kind)
	{
		return a->data.val;
	}
	else
	{
		if (ekId == a->kind)
		{
			onlyX(a->data.name);
			assert(e);
			return e->x;
		}

	}
	fprintf(stderr, "OOPS: tried to get the value of a non-expression(%d)\n", a->kind);
	exit(1);
}
static int execBinExpression(struct ExecEnviron* e, struct AstElement* a)
{
	assert(ekBinExpression == a->kind);
	const int left = dispatchExpression(e, a->data.expression.left);
	const int right = dispatchExpression(e, a->data.expression.right);
	char* op = a->data.expression.op;
	if (strcmp(op, "+")) return left + right;
	if (strcmp(op, "-")) return left - right;
	if (strcmp(op, "*")) return left * right;
	if (strcmp(op, "/")) return left / right;
	if (strcmp(op, ">")) return left > right;
	if (strcmp(op, "<")) return left < right;
	fprintf(stderr, "OOPS: Unknown operator:%s\n", a->data.expression.op); exit(1);
	/* no return here, since every switch case returns some value (or bails out) */
}
static void	execAssignment(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(ekAssignment == a->kind);
	onlyX(a->data.assignment.name);
	assert(e);
	struct AstElement* r = a->data.assignment.right;
	e->x = dispatchExpression(e, r);
}
static void	execWhile(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(ekWhile == a->kind);
	struct AstElement* const c = a->data.whileStatement.cond;
	struct AstElement* const s = a->data.whileStatement.statements;
	assert(c);
	assert(s);
	while (dispatchExpression(e, c))
	{
		dispatchStatement(e, s);
	}
		
}
static void execFunctionCall(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(ekCall == a->kind);
	onlyPrint(a->data.functionCall.name);
	printf("%d\n", dispatchExpression(e, a->data.functionCall.param));
}
static void	execStmt(struct ExecEnviron* e, struct AstElement* a)
{
	assert(a);
	assert(ekStatements == a->kind);
	for (int i = 0; i < a->data.statements.count; i++)
	{
		dispatchStatement(e, a->data.statements.statements[i]);
	}
}

void execAST(struct ExecEnviron* e, struct AstElement* a)
{
	dispatchStatement(e, a);
}

struct ExecEnviron* createEnv()
{
	assert(ekLastElement == (sizeof(valExecs) / sizeof(*valExecs)));
	assert(ekLastElement == (sizeof(runExecs) / sizeof(*runExecs)));
	return calloc(1, sizeof(struct ExecEnviron));
}

void freeEnv(struct ExecEnviron* e)
{
	free(e);
}


