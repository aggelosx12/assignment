#ifndef _ASTEXEC_H_
#define _ASTEXEC_H_

struct AstElement;
struct ExecEnviron;

/* creates the execution engine */
struct ExecEnviron* createEnv();

/* removes the ExecEnviron */
void freeEnv(struct ExecEnviron* e);

/* executes an AST */
void execAST(struct ExecEnviron* e, struct AstElement* a);

#endif