#ifndef AST_H
#define AST_H

struct AstElement
	{
		enum { ekId, ekNumber, ekBinExpression, ekAssignment, ekWhile, ekCall, ekStatements, ekLastElement 
		} kind;
		union
		{
			int val;
			char* name;
			struct
			{
				struct AstElement * left, * right;
				char* op;
			} expression;
			struct
			{
				char* name;
				struct AstElement* right;
			} assignment;
			struct
			{
				int count;
				struct AstElement** statements;
			} statements;
			struct
			{
				struct AstElement* cond;
				struct AstElement* statements;
			} whileStatement;
			struct
			{
				char* name;
				struct AstElement* param;
			} functionCall;
			
		} data;
	};

struct AstElement* makeAssignment(char* name, struct AstElement* val);
struct AstElement* makeMinusNum(struct AstElement* expr);
struct AstElement* makePlusNum(struct AstElement* expr);
struct AstElement* makeExpByNum(int val);
struct AstElement* makeExpByName(char* name);
struct AstElement* makeExpression(struct AstElement* left, struct AstElement* right, char* op);
struct AstElement* makeStatement(struct AstElement* result, struct AstElement* toAppend);
struct AstElement* makeWhile(struct AstElement* cond, struct AstElement* exec);
struct AstElement* makeFunctionCall(char* name, struct AstElement* param);

#endif