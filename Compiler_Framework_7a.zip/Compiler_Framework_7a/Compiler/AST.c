#include "AST.h"
#include <stdio.h>
#include <stdlib.h>
//#include <string.h>
#include <assert.h>

#define PRINT_NODES 1
//AST_7
char* getNodeKindName(int kind)
{
	switch (kind)
	{
		case ekId				: return "Identifier";
		case ekNumber			: return "Number";
		case ekBinExpression	: return "BinExpression";
		case ekAssignment		: return "Assignment";
		case ekWhile			: return "WhileStmt";
		case ekCall				: return "FunctionCall";
		case ekStatements		: return "Statements";
		case ekLastElement		: return "LastElement";
		default					: return "?uknown";
	}
}


static void* checkAlloc (size_t sz)
{
	void* result = calloc(sz, 1);
	if (!result)
	{
		fprintf(stderr, "AstElement alloc failed\n");
		exit(1);
	}
}

struct AstElement* makeAssignment(char* name, struct AstElement* expr)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekAssignment;
	result->data.assignment.name = name;
	result->data.assignment.right = expr;
	if (PRINT_NODES) printf("makeAssignment: %s, \t%s <- %s\n", getNodeKindName(ekAssignment), name , getNodeKindName(expr->kind));
	return result;
}
struct AstElement* makeMinusNum(struct AstElement* expr)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekNumber;
	result->data.val = -expr->data.val;
	if (PRINT_NODES) printf("makeMinusNum: %s, \tval: %d\n", getNodeKindName(ekNumber), -expr->data.val);
	return result;
}

struct AstElement* makePlusNum(struct AstElement* expr)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekNumber;
	result->data.val = expr->data.val;
	if (PRINT_NODES) printf("makePlusNum: %s, \tval: %d\n", getNodeKindName(ekNumber), expr->data.val);
	return result;
}

struct AstElement* makeExpByNum(int val)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekNumber;
	result->data.val = val;
	if (PRINT_NODES) printf("makeExpByNum: %s, \tval: %d\n", getNodeKindName(ekNumber), val);
	return result;
}
struct AstElement* makeExpByName(char* name)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekId;
	result->data.name = name;
	if (PRINT_NODES) printf("makeExpByName: %s, \tname: %s\n", getNodeKindName(ekId), name);
	return result;
}
struct AstElement* makeExpression(struct AstElement* left, struct AstElement* right, char* op)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekBinExpression;
	result->data.expression.left = left;
	result->data.expression.right = right;
	result->data.expression.op = op;
	if (PRINT_NODES) printf("makeExpression: %s, \t %s %s %s\n", getNodeKindName(ekBinExpression), getNodeKindName(left->kind), op, getNodeKindName(right->kind));
	return result;
}
struct AstElement* makeStatements(struct AstElement* result, struct AstElement* toAppend) 
{
	if (!result)
	{
		result = checkAlloc(sizeof(*result));
		result->kind = ekStatements;
		result->data.statements.count = 0;
		result->data.statements.statements = 0;
	}
	assert(ekStatements == result->kind);
	result->data.statements.count++;
	result->data.statements.statements = 
		realloc(result->data.statements.statements, result->data.statements.count*sizeof(*result->data.statements.statements));
	result->data.statements.statements[result->data.statements.count-1] = toAppend;
	if (PRINT_NODES) printf("makeStatements: %s, \tcount: %d, \tappend: %s\n", getNodeKindName(ekStatements), result->data.statements.count, getNodeKindName(toAppend->kind));
	return result;
}
struct AstElement* makeWhile(struct AstElement* cond, struct AstElement* exec)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekWhile;;
	result->data.whileStatement.cond = cond;
	result->data.whileStatement.statements = exec;
	if (PRINT_NODES) printf("makeWhile: %s, \tcond: %s, \tparam: %s\n", getNodeKindName(ekWhile), getNodeKindName(cond->kind), getNodeKindName(exec->kind));
	return result;
}
struct AstElement* makeFunctionCall(char* name, struct AstElement* param)
{
	struct AstElement* result = checkAlloc(sizeof(*result));
	result->kind = ekCall;
	result->data.functionCall.name = name;
	result->data.functionCall.param = param;
	if (PRINT_NODES) printf("makeFunctionCall: %s, \tfunction: %s (%s)\n", getNodeKindName(ekCall), name, getNodeKindName(param->kind));
	return result;
}

