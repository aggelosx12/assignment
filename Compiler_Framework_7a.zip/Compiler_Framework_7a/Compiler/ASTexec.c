#include "ASTexec.h"
#include "AST.h"
#include <stdlib.h>
//#include <string.h>
#include <assert.h>
#include <stdio.h>

//ASTexec 7.1
struct ExecEnviron
{
	int x; /* The value of the x variable, a real language would have some name->value lookup table instead */
};


static int execTermExpression(struct ExecEnviron* e, struct AstElement* a);
static int execBinExpression(struct ExecEnviron* e, struct AstElement* a);
static void	execAssignment(struct ExecEnviron* e, struct AstElement* a);
static void	execWhile(struct ExecEnviron* e, struct AstElement* a);
static void execFunctionCall(struct ExecEnviron* e, struct AstElement* a);
static void	execStatements(struct ExecEnviron* e, struct AstElement* a);

/* Lookup Array for AST elements which yields values */
static int (*valExecs[])(struct ExecEnviron* e, struct AstElement* a) =
{
	execTermExpression,
	execTermExpression,
	execBinExpression,
	NULL,
	NULL,
	NULL,
	NULL
};

/* Lookup Array for non-value AST elements */
static void (*runExecs[])(struct ExecEnviron* e, struct AstElement* a) =
{
	NULL, /* ID and numbers are canonical and don't need to be executed */
	NULL,
	NULL,
	execAssignment,
	execWhile,
	execFunctionCall,
	execStatements
};

static int dispatchExpression(struct ExecEnviron* e, struct AstElement* a)
{
	//printf("dispatchExpression: %s\t", getNodeKindName(a->kind));
	//printf("x = %d\n", e->x);

	assert(a);
	assert(valExecs[a->kind]);
	return valExecs[a->kind](e, a);
}

static void dispatchStatement(struct ExecEnviron* e, struct AstElement* a)
{
	//printf("dispatchStatement: %s\t", getNodeKindName(a->kind));
	//printf("x = %d\n", e->x);

	assert(a);
	assert(runExecs[a->kind]);
	runExecs[a->kind](e, a);
}


static void onlyName(const char* name, const char* reference, const char* kind)
{
	//printf("onlyName: name: %s, reference: %s, kind: %s, \n", name, reference, kind);
	if (strcmp(reference, name))
	{
		printf("Error! This language knows only the %s '%s', not '%s'\n", kind, reference, name);
		exit(1);
	}
}

static void onlyX(const	char* name)
{
	//printf("onlyX: %s\n", name);
	onlyName(name, "x", "variable");
}

static void	onlyPrint(const	char* name)
{
	//printf("onlyPrint: %s\n", name);
	onlyName(name, "PRINT", "function");
}

static int execTermExpression(struct ExecEnviron* e, struct AstElement* a)
{
	printf("\t exec: %s", getNodeKindName(a->kind));
	/* This function handles two different kinds of	AstElement.
	* I would refactor it to an execNameExp and execVal
	* function to get rid of this two if statements. */
	assert(a);
	int result = 0;
	if (ekNumber == a->kind)
	{
		result = a->data.val;
	}
	else
	{
		if (ekId == a->kind)
		{
			onlyX(a->data.name);
			assert(e);
			result = e->x;
		}

	}
	printf(" = %d\n", result);

	return result;
	printf("Error! OOPS: tried to get the value of a non-expression(%d)\n", a->kind);
	exit(1);
}
static int execBinExpression(struct ExecEnviron* e, struct AstElement* a)
{
	printf("\t exec: %s\n", getNodeKindName(a->kind));

	assert(ekBinExpression == a->kind);
	const int left = dispatchExpression(e, a->data.expression.left);
	const int right = dispatchExpression(e, a->data.expression.right);
	char* op = a->data.expression.op;

	int result=0;
	if (strcmp(op, "+")==0) result = left + right;
	if (strcmp(op, "-")==0) result = left - right;
	if (strcmp(op, "*")==0) result = left * right;
	if (strcmp(op, "/")==0) result = left / right;
	if (strcmp(op, ">")==0) result = (left > right);
	if (strcmp(op, "<")==0) result = (left < right);

	printf("\t result: %d = %d %s %d\n", result, left, op, right);
	return result;

	printf("Error! OOPS: Unknown operator:%s\n", a->data.expression.op); exit(1);
	/* no return here, since every switch case returns some value (or bails out) */
}
static void	execAssignment(struct ExecEnviron* e, struct AstElement* a)
{
	printf("\t exec: %s", getNodeKindName(a->kind));
	printf(" Identifier: %s\n", a->data.assignment.name);

	assert(a);
	assert(ekAssignment == a->kind);
	onlyX(a->data.assignment.name);
	assert(e);
	struct AstElement* r = a->data.assignment.right;
	e->x = dispatchExpression(e, r);
}
static void	execWhile(struct ExecEnviron* e, struct AstElement* a)
{
	printf(">> exec: %s\n", getNodeKindName(a->kind));

	assert(a);
	assert(ekWhile == a->kind);
	struct AstElement* const c = a->data.whileStatement.cond;
	struct AstElement* const s = a->data.whileStatement.statements;
	assert(c);
	assert(s);
	
	while (dispatchExpression(e, c))
	{
		dispatchStatement(e, s);
	}	
	printf("<< While terminated!\n");
}
static void execFunctionCall(struct ExecEnviron* e, struct AstElement* a)
{
	printf("\t exec: %s", getNodeKindName(a->kind));
	printf(" Function: %s\n", a->data.functionCall.name);
	
	assert(a);
	assert(ekCall == a->kind);
	onlyPrint(a->data.functionCall.name);

}
static void	execStatements(struct ExecEnviron* e, struct AstElement* a)
{
	printf(">> exec: %s count: %d\n", getNodeKindName(a->kind), a->data.statements.count);
	
	assert(a);
	assert(ekStatements == a->kind);
	for (int i = 0; i < a->data.statements.count; i++)
	{
		dispatchStatement(e, a->data.statements.statements[i]);
	}
	printf("<< Statements dispatched!\n");
}

void execAST(struct ExecEnviron* e, struct AstElement* a)
{
	printf("------\nexec: AST\n");

	dispatchStatement(e, a);
}

struct ExecEnviron* createEnv()
{
	assert(ekLastElement == (sizeof(valExecs) / sizeof(*valExecs)));
	assert(ekLastElement == (sizeof(runExecs) / sizeof(*runExecs)));
	return calloc(1, sizeof(struct ExecEnviron));
}

void freeEnv(struct ExecEnviron* e)
{
	free(e);
}


