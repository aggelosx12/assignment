#ifndef ASTEXEC_H
#define ASTEXEC_H
//ASTexec 7.1
struct AstElement;
struct ExecEnviron;

/* creates the execution engine */
struct ExecEnviron* createEnv();

/* removes the ExecEnviron */
void freeEnv(struct ExecEnviron* e);

/* executes an AST */
void execAST(struct ExecEnviron* e, struct AstElement* a);

/* prints an AST */
//void printAST(struct ExecEnviron* e, struct AstElement* a);

#endif